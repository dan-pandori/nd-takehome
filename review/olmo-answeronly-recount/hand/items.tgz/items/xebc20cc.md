# item xebc20cc

## Prompt

Your response must include bullet points denoted by * and at least one sub-bullet point denoted by - for each bullet point. Ensure that stop words constitute no more than 27% of the total words in your response. Write a fictional, imaginative, descriptive timeline of an alternate universe where the new world was only discovered in the 1900s with the advent of satellites

## Constraints

- format:sub-bullets {} -> checker: followed
- ratio:stop_words {"percentage": 27.0} -> checker: followed

## Answer

* 1899 Astronomers detect strange radio signals deep space  
  - Origins unknown sparking occult theories  
* 1910 Theoretical satellite proposal advanced  
  - No technological means yet exist  
* 1957 First artificial satellite reveals Terra Nova  
  - Mirror Earth hidden beyond solar system  
* 1960s Global space race prioritizes new world  
  - Resource wars ravage Earth  
* 1980 Colonization begins under international treaty  
  - Biomes adapted using genetic engineering  
* 2000 Political factions emerge between Terra Nova colonists  
  - Calls independence autonomy
