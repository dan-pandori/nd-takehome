# item xcaeb2a6

## Prompt

Suppose a sequence of polynomials B_n(x) converge pointwise to f(x) on [0, 1]. Does it follow that the B_n converge uniformly? Ensure that stop words constitute no more than 20% of the total words in your response.

## Constraints

- ratio:stop_words {"percentage": 20.0} -> checker: followed

## Answer

x^n [0,1] counterexample.
