# item xdf76aab

## Prompt

Each word in your response must start with the next letter of the alphabet, looping back to 'A' after 'Z'. Transform the poetic stanza into a description for an anime.  We are the school idols, hearts on fire, Singing our stories, reaching higher. Together we shine, a symphony, In this dance of youth and melody.

## Constraints

- words:alphabet {} -> checker: followed

## Answer

A band creates dynamic energy fans great hearts igniting joy keenly lights melodies now overcome problems questing reach school talents united vividly worldwide xylophones youth zeal.
