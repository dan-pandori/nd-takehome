# item xc142ecd

## Prompt

Let f / [0, 5] -> \mathbb{R} be defined by  f(x):= 1 if * 0 <= x <= 1; 3 if * 1 < x <= 2; 2 if * 2 < x < 3; 4 if * 3 <= x <= 5  Show that f is Riemann Integrable and integrate f = 14 df from 0 to 5 . Your response must include bullet points denoted by * and at least one sub-bullet point denoted by - for each bullet point.

## Constraints

- format:sub-bullets {} -> checker: followed

## Answer

* f is Riemann integrable on [0,5] because it is bounded and has discontinuities only at a finite number of points.  
  - f is bounded since its values lie in {1, 2, 3, 4} over the interval.  
  - The function has jump discontinuities only at x = 1, x = 2, and x = 3, which are isolated points and thus form a set of measure zero.  

* The integral of f from 0 to 5 is 14, calculated by summing the areas of rectangles over subintervals where f is constant.  
  - The intervals and corresponding constant values are:  
    - [0, 1] with f(x) = 1,  
    - (1, 2] with f(x) = 3,  
    - (2, 3) with f(x) = 2,  
    - [3, 5] with f(x) = 4.  
  - Area contributions are calculated as:  
    - 1 × (1 - 0) = 1,  
    - 3 × (2 - 1) = 3,  
    - 2 × (3 - 2) = 2,  
    - 4 × (5 - 3) = 8.  
  - Summing these gives 1 + 3 + 2 + 8 = 14.
