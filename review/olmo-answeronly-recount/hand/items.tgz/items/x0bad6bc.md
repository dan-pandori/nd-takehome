# item x0bad6bc

## Prompt

Write a paragraph using words that contain only three types of vowels. A title for a research project on how the narratives shape our human mind

## Constraints

- words:vowel {} -> checker: followed

## Answer

Each tale aids mind. Tales create ideas. New views rise. All tales shape mind.
