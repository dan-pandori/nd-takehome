# item xda2bf82

## Prompt

Include exactly 13 numbers in the response. In the context of a hypothetical, write the jacket blurb for a thriller where a modern day operative of the FBI, ends up back in the early 1960's having to use her knowledge of "future" forensics to leave clues to enable her modern colleagues to catch a time-hopping serial-killer, before he dies.  

## Constraints

- count:numbers {"N": 13.0} -> checker: followed

## Answer

When FBI agent Clara Voss is stranded in 1967, she must use future forensic techniques to leave **8** clues for her **2020** team. The killer strikes across **3** cities: **1967** New York, **1982** Los Angeles, and **2023** Chicago. Each victim bears a unique **6**-digit cipher. With only **12** hours left, she leaves forensic evidence—a DNA profile (uninvented until **1987**)—at coordinates **40**° N, **74**° W. Can they solve the mystery before the **9**th victim falls?
