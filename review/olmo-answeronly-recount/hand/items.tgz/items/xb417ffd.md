# item xb417ffd

## Prompt

Write a paragraph using words that contain only three types of vowels. what is most beautiful on life?

## Constraints

- words:vowel {} -> checker: followed

## Answer

Life's greatest gift is peace. Each tiny time keeps light. Kindness and fine hearts make earth sweet. Seek light in simple sights.
