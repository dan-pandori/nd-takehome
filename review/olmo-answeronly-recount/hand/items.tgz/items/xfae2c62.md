# item xfae2c62

## Prompt

Write a descriptive, fictional, imaginative screenplay from an alternate universe where the Apollo 11 lunar module suddenly stopped working. The astronauts were doomed, and were forced to take cyanide pills and slowly lose consciousness as they listen to nixon's speech about how much they will be considered heroes. Create stairs by incrementally indenting each new line.

## Constraints

- format:line_indent {} -> checker: followed

## Answer

Apollo 11 lunar module shudders violently in the moon's shadow  
  Alarms blare with a piercing frequency  
    Red warning lights flash across the control panel  
      Neil Armstrong's voice crackles through the radio: "Houston we have a critical failure"  
        Mission Control responds their words swallowed by static "...were working on it"  
          Buzz Aldrin calculates furiously his face pale behind his helmet  
            The numbers on the display spiral into meaninglessness  
              A small compartment clicks open revealing two cyanide capsules  
                Nixon's recorded speech begins to play distorted by transmission "These brave men"  
                  Armstrong's hand trembles as he unscrews the cap  
                    He drinks  
                      Buzz follows pill dissolving on his tongue  
                        Static mixes with fading speech "...shall not have died in vain"  
                          Consciousness recedes Shadows lengthen across the moonlit module  
                            Last transmission fragments "...save the moonwalk footage"  
                              Darkness consumes the cabin Earth sighs Alone
