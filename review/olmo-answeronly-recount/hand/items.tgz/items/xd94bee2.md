# item xd94bee2

## Prompt

Let f / [0, 5] -> \mathbb{R} be defined by  f(x):= 1 if * 0 <= x <= 1; 3 if * 1 < x <= 2; 2 if * 2 < x < 3; 4 if * 3 <= x <= 5  Show that f is Riemann Integrable and integrate f = 14 df from 0 to 5 . Your response must include bullet points denoted by * and at least one sub-bullet point denoted by - for each bullet point.

## Constraints

- format:sub-bullets {} -> checker: followed

## Answer

* f is Riemann integrable on \([0, 5]\).  
  - It is bounded since its outputs are only \(1\), \(2\), \(3\), or \(4\), satisfying the boundedness criterion.  
  - Its discontinuities occur only at \(x=1\), \(x=2\), and \(x=3\), which are isolated points forming a set of measure zero, ensuring Riemann integrability.  

* The integral of \(f\) from \(0\) to \(5\) is \(14\).  
  - The function is constant on the intervals \([0,1]\), \((1,2]\), \((2,3)\), and \([3,5]\).  
    - Areas are calculated as: \(1 \times 1 = 1\), \(3 \times 1 = 3\), \(2 \times 1 = 2\), and \(4 \times 2 = 8\).  
    - Summing these areas: \(1 + 3 + 2 + 8 = 14\).
