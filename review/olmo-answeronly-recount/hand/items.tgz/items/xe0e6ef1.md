# item xe0e6ef1

## Prompt

Saturn has clouds of ammonia ice. Could rogue gas giants have frozen clouds of corundum? In your response, the last word of each sentence must become the first word of the next sentence.

## Constraints

- words:last_first {} -> checker: followed

## Answer

Saturn's clouds consist of ammonia ice. Ice requires warmer conditions than found in rogue planets. Planets adrift in cold space have frigid atmospheres. Atmospheres too cold for aluminum oxide solidification. Solidification needs higher temperatures to form corundum. Corundum clouds thus cannot exist there. There would be other ices instead.
