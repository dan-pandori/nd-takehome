# item x92cffdc

## Prompt

Write a Female character who can create ghostly clones of herself, each from different timelines, which do everything she can possibly do in certain situations. Your response must include bullet points denoted by * and at least one sub-bullet point denoted by - for each bullet point. Ensure that stop words constitute no more than 9% of the total words in your response.

## Constraints

- format:sub-bullets {} -> checker: followed
- ratio:stop_words {"percentage": 9.0} -> checker: followed

## Answer

* Dystopian clone combats threats -: Summons spectral blades.  
- Alternate-timeline self manipulates energy -: Forges gravitational wells.  
* Utopian variant engineers solutions -: Constructs holographic cities.  
- Mystic echo evades detection -: Phases through solid matter.  
* Diplomat clone resolves conflicts -: Alters memories subtly.  
- Chronomancer fragment predicts outcomes -: Warps local time streams.
