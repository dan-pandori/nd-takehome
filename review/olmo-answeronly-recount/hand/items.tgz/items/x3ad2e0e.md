# item x3ad2e0e

## Prompt

Let f / [0, 5] -> \mathbb{R} be defined by  f(x):= 1 if * 0 <= x <= 1; 3 if * 1 < x <= 2; 2 if * 2 < x < 3; 4 if * 3 <= x <= 5  Show that f is Riemann Integrable and integrate f = 14 df from 0 to 5 . Your response must include bullet points denoted by * and at least one sub-bullet point denoted by - for each bullet point.

## Constraints

- format:sub-bullets {} -> checker: followed

## Answer

* The function \( f \) is Riemann integrable on \([0, 5]\).  
  - \( f \) is bounded (values between 1 and 4) and has discontinuities only at \( x = 1, 2, 3 \), which are isolated points. A finite set of discontinuities has measure zero, satisfying Riemann’s integrability conditions.  

* The integral of \( f \) over \([0, 5]\) is computed by summing the areas of its constant-value intervals.  
  - Calculate each subinterval:  
    - \([0, 1]\): \( 1 \times 1 = 1 \),  
    - \((1, 2]\): \( 3 \times 1 = 3 \),  
    - \((2, 3)\): \( 2 \times 1 = 2 \),  
    - \([3, 5]\): \( 4 \times 2 = 8 \).  
  - Total integral: \( 1 + 3 + 2 + 8 = 14 \).
