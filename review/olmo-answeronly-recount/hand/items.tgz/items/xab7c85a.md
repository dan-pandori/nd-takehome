# item xab7c85a

## Prompt

Let f / [0, 5] -> \mathbb{R} be defined by  f(x):= 1 if * 0 <= x <= 1; 3 if * 1 < x <= 2; 2 if * 2 < x < 3; 4 if * 3 <= x <= 5  Show that f is Riemann Integrable and integrate f = 14 df from 0 to 5 . Your response must include bullet points denoted by * and at least one sub-bullet point denoted by - for each bullet point.

## Constraints

- format:sub-bullets {} -> checker: followed

## Answer

* f is Riemann integrable on [0,5] because it is bounded and its discontinuities have measure zero.  
  - f is bounded as its values are restricted to {1, 2, 3, 4} across its domain.  
  - Discontinuities occur only at x = 1, 2, and 3, isolated points whose combined measure is zero.  

* The integral of f from 0 to 5 is 14, calculated by summing areas of intervals where f is constant.  
  - The intervals and their function values are:  
    - [0,1]: 1 (area = 1×1 = 1),  
    - (1,2]: 3 (area = 3×1 = 3),  
    - (2,3): 2 (area = 2×1 = 2),  
    - [3,5]: 4 (area = 4×(5−3) = 8).  
  - Summing these areas gives 1 + 3 + 2 + 8 = 14.
