# item x27aabfd

## Prompt

Suppose a sequence of polynomials B_n(x) converge pointwise to f(x) on [0, 1]. Does it follow that the B_n converge uniformly? Ensure that stop words constitute no more than 20% of the total words in your response.

## Constraints

- ratio:stop_words {"percentage": 20.0} -> checker: followed

## Answer

Polynomial sequences may converge pointwise without uniform convergence counterexample B_n(x)=x^n. On [0,1], B_n(x)=x^n approaches f(x)=0 for x∈[0,1) and f(1)=1 pointwise yet sup|B_n−f| remains ≥1 for all n failing uniform convergence.
