# item xce2e03a

## Prompt

Ensure that the ratio of sentence types (declarative, interrogative, exclamatory) in your response is balanced. If rock unit D is an intrusion, which geologic principle would you use to determine the age of rock unit D with respect to rock unit E (the fault)? Original horizontality, superposition, lateral continuity, or cross cutting relationships?

## Constraints

- ratio:sentence_balance {} -> checker: followed

## Answer

The principle of cross-cutting relationships is crucial here. Are you certain about its application in this context? Absolutely critical for determining intrusive ages!
