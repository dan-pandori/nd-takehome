# item xc4cc3ef

## Prompt

Saturn has clouds of ammonia ice. Could rogue gas giants have frozen clouds of corundum? In your response, the last word of each sentence must become the first word of the next sentence.

## Constraints

- words:last_first {} -> checker: followed

## Answer

Saturn has ammonia clouds. Clouds form under specific temperature ranges. Ranges for corundum are very high. High pressures and heat required. Required conditions may not exist.
