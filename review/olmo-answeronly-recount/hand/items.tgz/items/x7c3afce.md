# item x7c3afce

## Prompt

Ensure that the ratio of sentence types (declarative, interrogative, exclamatory) in your response is balanced. If rock unit D is an intrusion, which geologic principle would you use to determine the age of rock unit D with respect to rock unit E (the fault)? Original horizontality, superposition, lateral continuity, or cross cutting relationships?

## Constraints

- ratio:sentence_balance {} -> checker: followed

## Answer

Cross-cutting relationships are the appropriate principle. Does this account for the intrusion's relationship with the fault? Yes, decisively!
