# item xe0e09da

## Prompt

Saturn has clouds of ammonia ice. Could rogue gas giants have frozen clouds of corundum? In your response, the last word of each sentence must become the first word of the next sentence.

## Constraints

- words:last_first {} -> checker: followed

## Answer

Saturn has ammonia clouds. Clouds form under specific temperature ranges. Ranges for corundum require high pressures. Pressures and extreme heat enable crystallization. Crystallization demands conditions rogue planets lack. Lack of required environments makes such clouds improbable.
