# item xcdc52f7

## Prompt

Ensure that the ratio of sentence types (declarative, interrogative, exclamatory) in your response is balanced. If rock unit D is an intrusion, which geologic principle would you use to determine the age of rock unit D with respect to rock unit E (the fault)? Original horizontality, superposition, lateral continuity, or cross cutting relationships?

## Constraints

- ratio:sentence_balance {} -> checker: followed

## Answer

The principle to use is cross-cutting relationships. Could there be exceptions in fault scenarios? This ensures accurate age determination!
