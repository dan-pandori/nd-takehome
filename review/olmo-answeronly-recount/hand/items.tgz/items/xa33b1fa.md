# item xa33b1fa

## Prompt

Count from 10 to 50 but only print multiples of 7.

## Constraints

- custom:multiples {} -> checker: followed

## Answer

<answer>
14, 21, 28, 35, 42, 49
</answer>
