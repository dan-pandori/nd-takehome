# item xbcef5e0

## Prompt

Let f / [0, 5] -> \mathbb{R} be defined by  f(x):= 1 if * 0 <= x <= 1; 3 if * 1 < x <= 2; 2 if * 2 < x < 3; 4 if * 3 <= x <= 5  Show that f is Riemann Integrable and integrate f = 14 df from 0 to 5 . Your response must include bullet points denoted by * and at least one sub-bullet point denoted by - for each bullet point.

## Constraints

- format:sub-bullets {} -> checker: followed

## Answer

* f is Riemann integrable on [0,5] because it is bounded and discontinuities form a set of measure zero.  
  - Boundedness: f only takes values 1, 2, 3, and 4 over [0,5].  
  - Discontinuities: Finitely many points (x=1, 2, 3) are isolated and have measure zero.  

* The integral of f from 0 to 5 is calculated by summing areas of rectangles over its constant intervals.  
  - Interval breakdown:  
    - [0,1]: f(x)=1, length =1 → Area =1×1=1  
    - (1,2]: f(x)=3, length =1 → Area =3×1=3  
    - (2,3): f(x)=2, length =1 → Area =2×1=2  
    - [3,5]: f(x)=4, length =2 → Area =4×2=8  
  - Total integral: 1 + 3 + 2 + 8 = 14.
