# item xcb1b89d

## Prompt

Each word in your response must start with the next letter of the alphabet, looping back to 'A' after 'Z'. Transform the poetic stanza into a description for an anime.  We are the school idols, hearts on fire, Singing our stories, reaching higher. Together we shine, a symphony, In this dance of youth and melody.

## Constraints

- words:alphabet {} -> checker: followed

## Answer

Adolescent bands create dreams every fantastic gig has incredible joy kindling love melodies nightly operas passionately questing reaching summits together uniting voices worldwide xenial youth zeal.
