# item xc298aea

## Prompt

Each word in your response must start with the next letter of the alphabet, looping back to 'A' after 'Z'. Transform the poetic stanza into a description for an anime.  We are the school idols, hearts on fire, Singing our stories, reaching higher. Together we shine, a symphony, In this dance of youth and melody.

## Constraints

- words:alphabet {} -> checker: followed

## Answer

A brave chorus dances enchantingly fusing great harmonies in joyful kaleidoscope lights melodies nurturing our passion quest reaching symphony together unified voices weave xenon youth zenith
