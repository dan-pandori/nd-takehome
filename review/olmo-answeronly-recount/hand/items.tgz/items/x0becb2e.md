# item x0becb2e

## Prompt

Suppose a sequence of polynomials B_n(x) converge pointwise to f(x) on [0, 1]. Does it follow that the B_n converge uniformly? Ensure that stop words constitute no more than 20% of the total words in your response.

## Constraints

- ratio:stop_words {"percentage": 20.0} -> checker: followed

## Answer

No xn on [0,1] pointwise discontinuous function lacks uniform convergence. Example: \( B_n(x) = x^n \) converges pointwise to \( f(x) = 0 \) on \([0,1)\) and \( f(1) = 1 \), which is discontinuous. Since uniform convergence preserves continuity, convergence cannot be uniform.
