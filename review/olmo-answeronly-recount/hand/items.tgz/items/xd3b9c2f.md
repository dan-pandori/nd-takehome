# item xd3b9c2f

## Prompt

Write a descriptive, fictional, imaginative screenplay of a mental asylum doctor ordering a schizophrenic patient to take his pills, the patient refuses, and makes him take the pills to prove they are safe. The doctor obliges, but when he opens his eyes, the patient is gone, a figment of his imagination, revealing it was the doctor that was schizophrenic the whole time.  Please use an emoji at the end of every sentence.

## Constraints

- format:emoji {} -> checker: followed

## Answer

The camera glides through dimly lit asylum halls. 🏥  
DR. ELIAS Voss, 48, adjusts his crooked tie. 👔  
A sign reads “Ward 9: Psychiatric Care.” 🚪  
Inside Cell A-7, PATIENT X stares at the wall. 🔄  
“This ends now,” Dr. Voss snaps, clutching meds. 💊  
patient x tilts their head, pupils dilated. 👀  
“You’ll take your pills,” he orders. ⚖️  
“Or you’ll force me,” patient x giggles. 😈  
“You’re worse than the others,” he mutters. ☹️  
patient x leans closer, breath reeking of decay. 🦠  
“I’ll take the whole bottle,” they say. 💣  
Dr. Voss hesitates, then pops one himself. 🤢  
Another. 🔥  
The third sticks in his throat. 🌊  
patient x claps slowly. 👏  
“The taste… it’s familiar,” he rasps. 💤  
“You’ve been here so long you forget.” 🧩  
His reflection shifts—patient x’s face flickers. 🪐  
The pills scatter across concrete. 🥄  
Dr. Voss reaches for them. 🫙  
His hand—now patient x’s—grasps nothing. 👈  
The room dissolves into white noise. ⚡  
A orderly whispers, “Morning, patient x.” 🪐  
DR. VOS’s name badge slides off his shirt. 🌀  
FADE TO BLACK. ☠️
