# item x40b7ecb

## Prompt

Respond with three sentences, all containing the same number of characters but using all different words. According to some historians, after the fall of the Western Roman Empire and transition into the Middle Ages, it's said that the Franks contributed the most in defining the Middle Ages as a whole and continued to shape most of Europe up until the end of the Middle Ages. How true is this and what did they do to define the era?

## Constraints

- ratio:sentence_words {} -> checker: followed

## Answer

Franks significantly shaped medieval Europe's governance and cultures. They established Frankish realm affecting later European institutions. Their impact on legal societal religious structures was very profound.
