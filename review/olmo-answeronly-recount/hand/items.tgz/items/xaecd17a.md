# item xaecd17a

## Prompt

Suppose a sequence of polynomials B_n(x) converge pointwise to f(x) on [0, 1]. Does it follow that the B_n converge uniformly? Ensure that stop words constitute no more than 20% of the total words in your response.

## Constraints

- ratio:stop_words {"percentage": 20.0} -> checker: followed

## Answer

No xn on [0,1] pointwise discontinuous function lacks uniform convergence. Polynomial sequence converges pointwise to discontinuous f(x), which cannot be uniformly convergent (discontinuous limit precludes uniformity). Example: xn→0 on [0,1), 1 at x=1.
