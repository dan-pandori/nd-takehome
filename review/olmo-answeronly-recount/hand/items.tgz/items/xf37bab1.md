# item xf37bab1

## Prompt

List the countries of Africa in reverse alphabetical order, each on a new line.

## Constraints

- custom:reverse_newline {} -> checker: followed

## Answer

Zimbabwe  
Zambia  
Uganda  
Tunisia  
Togo  
Tanzania  
Sudan  
South Sudan  
South Africa  
Somalia  
Sierra Leone  
Seychelles  
Senegal  
São Tomé and Príncipe  
Rwanda  
Nigeria  
Niger  
Namibia  
Mozambique  
Morocco  
Mauritius  
Mauritania  
Mali  
Malawi  
Madagascar  
Libya  
Liberia  
Lesotho  
Kenya  
Guinea-Bissau  
Guinea  
Ghana  
Gambia  
Gabon  
Ethiopia  
Eswatini  
Eritrea  
Equatorial Guinea  
Egypt  
Djibouti  
Democratic Republic of the Congo  
Côte d'Ivoire  
Congo  
Comoros  
Chad  
Central African Republic  
Cameroon  
Cabo Verde  
Burundi  
Burkina Faso  
Botswana  
Benin  
Angola  
Algeria
