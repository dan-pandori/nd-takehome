# item x61abf5c

## Prompt

Write a paragraph using words that contain only three types of vowels. A title for a research project on how the narratives shape our human mind

## Constraints

- words:vowel {} -> checker: followed

## Answer

"Narratives shape ideas, tales alter feelings, as minds see links each tells. Ideas, images remain vital, minds take deeds, each mind keeps."
